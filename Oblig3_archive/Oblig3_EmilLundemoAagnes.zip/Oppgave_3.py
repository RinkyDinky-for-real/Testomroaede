fav_mat = ["Pizza","Grateng","Makaroni"]
def print_list(x):
    for i in range(len(x)):
        print(x[i])
print_list(fav_mat)